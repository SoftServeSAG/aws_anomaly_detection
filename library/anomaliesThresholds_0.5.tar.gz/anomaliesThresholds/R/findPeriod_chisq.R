#' Find fluctuation periods based on Sokolove and Bushell criterion
#'
#' @param x timeseries data in vector format
#' @param min.period (default 60) minimum possible period
#' @param max.period (default half of x) maximum possible period
#' @param step (default 1) step which will be used to determine vector of possible periods
#' @param alpha (default 0) significance level for ChiSq test
#' @param per_diff (default 100) minimum difference between periods
#' @param plt (default TRUE) if TRUE than periods will be plotted
#' @return the vector of found periods for timeseries
#' @details
#' Function is used to find fluctuation periods of timeseries.
#' It is recommended to use this function with reconstructed timeseries without trend component.
#' It could be done with \code{\link{app_timeseries}} function
#'
#' @examples
#' findPeriod_chisq(timeseries_examples[[1]])
#'
#' reconstructed_timeseries <- app_timeseries(timeseries_examples[[1]], trend = FALSE)
#' findPeriod_chisq(reconstructed_timeseries, alpha = 0.01)
#'
#' @export

findPeriod_chisq <- function(x,
                             min.period = 60,
                             max.period = length(x) / 2,
                             step = 1,
                             alpha = 0,
                             per_diff = 100,
                             plt = TRUE) {
        N <- length(x)
        variances = NULL
        periods = seq(min.period, max.period, by = step)
        rowlist = NULL
        for(lc in periods){
                ncol = lc
                nrow = floor(N/ncol)
                rowlist = c(rowlist, nrow)
                x.trunc = x[1:(ncol*nrow)]
                x.reshape = t(array(x.trunc, c(ncol, nrow)))
                variances = c(variances, var(colMeans(x.reshape)))
        }
        Qp = (rowlist * periods * variances) / var(x)
        df = periods - 1
        pvals = 1-pchisq(Qp, df)
        pass.periods = periods[pvals <= alpha]
        pass.pvals = pvals[pvals <= alpha]

        if (length(pass.periods) == 0) {
                return ("No periods were detected for x timeseries with following parameters.")
        }

        if (length(pass.periods) > 1) {
                n <- which(diff(pass.periods) > per_diff) + 1
                n <- c(1, n, length(pass.periods) + 1)
        }

        periods = NULL

        for (i in (1:(length(n) - 1))) {
                periods <- c(periods, round(sum(pass.periods[n[i]:(n[i+1]-1)] * ((1 - pass.pvals[n[i]:(n[i+1]-1)]) / (sum((1 - pass.pvals[n[i]:(n[i+1]-1)])))))))
        }

        periods <- sort(periods)

        if (plt == TRUE) {
                #x11(width = 30, height = 15)
                par(mfrow = c(1,length(periods)))
                for (i in 1:length(periods)) {
                        plot(x, type = "l", main = periods[i])
                        for (j in 1:floor(length(x) / periods[i])) {
                                abline(v = periods[i] * j, col = "red")
                        }
                }
        }
        return(periods)
}
