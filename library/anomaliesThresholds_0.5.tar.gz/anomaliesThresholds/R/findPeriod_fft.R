#' Find fluctuation periods based on fast Fourier transformation
#'
#' @param timeSeries timeseries data in vector format
#' @return the vector of found periods
#' @details
#' Function is used to find fluctuation periods of timeseries
#'
#' @examples
#' findPeriod_fft(timeseries_examples[[1]])
#'
#' x=0:205
#' timeseries1 <- ((sin(x/20*2*pi))+1)*50*runif(206,1,1.5)+((sin(x/100*2*pi))+1)*100
#' timeseries2 <- ((sin(x/20*2*pi))+1)*50*runif(206,0.1,1.5)
#' periods <- findPeriod_fft(timeseries1)
#' periods <- findPeriod_fft(timeseries2)
#'
#' @import Rssa igraph
#' @export

findPeriod_fft <- function (timeSeries) {

        r= ssa(timeSeries, L = round(length(timeSeries) / 2))
        print(plot(r))

        rr=reconstruct(r, groups=1:10)
        plot(rr)

        print(plot(rr,type="cumsum",plot.method="xyplot",add.original = FALSE, add.residuals = FALSE))
        print(plot(r, type = "vectors", vectors="factor",idx = 1:10, slice = list(k = 1, i = 1)))

        periods = NULL

        rr=reconstruct(r, groups=1:50)
        rr=data.frame(rr[1:9])

        for (i in(1:ncol(rr))){

                s=abs(fft(rr[,i]))[1:(length(rr[,i])/2)]
                s1=(s[which(!is.na(s))])
                s1[which(s1<max((s1))*0.3)]=0
                ts=max(which(s1>0))

                s2=s1[1:(ts+ts*0.3)];

                a=diff(s2,differences=1)
                b=diff(s2,differences=2)

                d1=which(a<0)
                d2=which(a>0)
                dd1=d1-1
                p1=intersect(d2,dd1)
                dd2=d2-1
                p2=intersect(dd2,d1)
                pp=sort(c(p1,p2)+1,decreasing = TRUE)
                d2res=b[pp-1]
                emax=pp[which(d2res<0)]

                period=length(rr[,i])/(emax*pi/2)*2

                periods=c(periods,period)
        }

        pp=periods[1]
        E=(periods[which(periods>pp)])
        E1=table(E)
        if (length(E) > 0) {
                pp=round(as.numeric(names(E1[E1==max(E1)])))
                periods <- c(round(periods[1]),pp[length(pp)])
        } else {
                periods <- round(periods[1])
        }

        for (i in 1:length(periods)) {
                plot(timeSeries, type = "l", main = paste(c("Period ", periods[i]), collapse = " "), xlab = "Time", ylab = "Timeseries value")
                for (j in 1:floor(length(timeSeries) / periods[i])) {
                        abline(v = periods[i] * j, col = "red")
                }
        }

        return(periods)
}
