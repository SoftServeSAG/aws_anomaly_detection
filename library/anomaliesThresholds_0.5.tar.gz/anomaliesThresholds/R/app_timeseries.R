#' Find timeseries approximation
#'
#' @param timeSeries timeseries data in vector format
#' @param trend (default TRUE) indicates if trend should be added to approximation form of timeseries
#' @param thresh (default 0.001) threshold for components importance (components with importance >= than thresh will be used to reconstruct timeseries)
#' @return reconstructed timeseries in vector format
#' @details
#' This function finds timeseries approximation based on spectrum analysis
#'
#' @examples
#' app_timeseries(timeseries_examples[[1]])
#' app_timeseries(timeseries_examples[[1]], trend = FALSE, thresh = 0.005)
#'
#' @import Rssa
#' @export

app_timeseries <- function(
        timeSeries,
        trend = TRUE,
        thresh = 0.001) {

        r= ssa(timeSeries, L = round(length(timeSeries) / 2))

        component_wnorm <- function(x) {
                idx <- seq_len(nsigma(x))
                x <- r
                total <- wnorm(x)^2
                x$sigma[idx]^2 / total
        }

        weights <- component_wnorm(r)

        n <- max(which(weights >= thresh))

        if (trend == TRUE) {
                rr=reconstruct(r, groups=1:n)
        } else {
                rr=reconstruct(r, groups=2:n)
        }

        timeSeries_reconstructed <- rep(0, length(rr[[1]]))

        for (i in 1:length(rr)) {
                timeSeries_reconstructed <- timeSeries_reconstructed + rr[[i]]
        }

        return(timeSeries_reconstructed)
}
