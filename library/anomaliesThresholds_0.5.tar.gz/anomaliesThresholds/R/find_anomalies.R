#' Detecting anomalies based on built model
#'
#' @param metric timeseries data in vector format
#' @param model model returned by \code{\link{build_model}} function
#' @param plt (default TRUE) if TRUE than thresholds will be plotted
#' @param plt_period (default NULL) if NULL then all periods will be plotted. It also could take integer value from range [1:number of the biggest periods]. In that case only one period will be plotted
#'
#' @return indexes of found anomalies
#'
#' @details
#' Function is used to predict thresholds for next periods based on linear trend in levels of the highest periods
#'
#' @examples
#'
#' train <- month_data[1:(length(month_data) * 2 / 3)]
#' test <- month_data[((length(month_data) * 2 / 3) + 1):length(month_data)]
#' reconstructed_timeseries <- app_timeseries(train, trend = TRUE)
#'
#' model <- build_model(metric = train,
#'                      metric_reconstructed = reconstructed_timeseries,
#'                      period = c(288, 7*288, 4*7*288),
#'                      prob_th = 0.9,
#'                      prob_agg = 0.7,
#'                      k = 0.1,
#'                      similar = 0.25,
#'                      corrected_by = c(1, 1, 1),
#'                      plt = TRUE,
#'                      plt_period = NULL,
#'                      identical_thresholds = c(FALSE, FALSE, FALSE))
#'
#' find_anomalies(metric = test, model = model, plt = TRUE)
#'
#' @export

find_anomalies <- function (metric, model, plt = TRUE, plt_period = NULL) {

        #Length of the biggest period (in number of points)
        last_period_length <- max(model$thresholds$Minute_High)

        for (i in 1:(length(model$levels) - 1)) {
                last_period_length <- last_period_length * length(model$levels[[i]])
        }

        #Index of prediction time
        prediction_time <- (length(model$levels[[length(model$levels)]]) + 1):(length(model$levels[[length(model$levels)]]) + ceiling(length(metric) / last_period_length))

        #Prediction of levels on periods of 'prediction_time'
        lm_df_train <- data.frame(time = (1:length(model$levels[[length(model$levels)]])), level = model$levels[[length(model$levels)]])
        lm_model <- lm(level ~ time, data = lm_df_train)

        lm_df_test <- data.frame(time = prediction_time)

        model$levels[[length(model$levels)]] <- as.numeric(predict(lm_df_test, object = lm_model))

        #Determining anomalies in data
        dts <- model$thresholds[rep(1:nrow(model$thresholds), floor(length(metric) / model$period[1])),]
        dts$Day <- rep(1:floor(length(metric) / model$period[1]), each = nrow(model$thresholds))

        dts$Threshold <- dts$Threshold * rep(rep(model$levels[[1]], times = length(model$levels[[2]])), each = nrow(model$thresholds))

        for (lev2 in 2:length(model$period)) {
                dts$Threshold <- dts$Threshold * rep(rep(model$levels[[lev2]], each = model$period[lev2] / model$period[1]), each = nrow(model$thresholds))

        }

        dts$Minute_Low <- dts$Minute_Low + (dts$Day - 1) * model$period[1]
        dts$Minute_High <- dts$Minute_High + (dts$Day - 1) * model$period[1]

        anomaly <- NULL

        dts$Len <- dts$Minute_High - dts$Minute_Low + 1

        a<-rep(dts$Threshold, dts$Len)

        anomaly <- metric > a

        #Plotting thresholds
        if (plt == TRUE) {

                par(oma = c(4, 1, 1, 1))

                plt_range <- c(1, length(metric))

                if (!is.null(plt_period)) {
                        plt_range <- c((1 + (plt_period-1)*model$period[length(model$period)]), (model$period[length(model$period)] + (plt_period-1)*model$period[length(model$period)]))
                }

                plot(metric, type = "l", ylim = c(1, 2 * max(metric)), xlim = plt_range, xlab = "Time", ylab = "Metric", xaxt='n', yaxt = "n", col = "black", cex.lab = 1.3)

                for (lev2 in 1:length(model$period)) {
                        for (i in 1:floor(length(metric) / model$period[lev2])) {
                                abline(v = model$period[lev2] * i, col = "tan1", lwd = lev2)
                        }
                }

                rect(dts$Minute_Low,
                     0,
                     dts$Minute_High,
                     dts$Threshold,
                     lty = 2,
                     density = 20,
                     col = 139)

                points(c(1:length(metric))[anomaly],
                       metric[anomaly],
                       col = "red",
                       pch = 16)


                axis(1, at=c(1, model$period[1] * (1:floor(length(metric) / model$period[1]))), labels = TRUE, tick = TRUE)
                axis(2, at=c(0, round(dts$Threshold)), labels = TRUE, tick = TRUE)

                legend("bottom",
                       legend = c("TimeSeries", "Anomaly", "Normal zone"),
                       lwd = 1, cex = 1,
                       xpd = TRUE,
                       horiz = TRUE,
                       inset = c(0,1),
                       bty = "n",
                       col = c("gray", "red", 139),
                       lty = c(1, NA, 2),
                       pch = c(NA, 16, NA))
        }

        return(which(anomaly == TRUE))
}
